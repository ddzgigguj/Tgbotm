"""
База данных персонажей MKX v4.0 (Enhanced)
Добавлены ELO-рейтинги и статистика для улучшенного анализа
"""

# === ПАЛАЧИ (Те, кто делают Fatality/Brutality в 70%+ случаев) ===
EXECUTORS = {
    "Джейсон": {"role": "Палач-Стабильность", "best_round": 2, "winrate": 78.5, "elo": 1850, "aliases": ["Jason", "Voorhees", "Вурхиз"]},
    "Джейсон Вурхиз": {"role": "Палач-Стабильность", "best_round": 2, "winrate": 78.5, "elo": 1850, "aliases": ["Jason", "Voorheес"]},
    "Jason": {"role": "Палач-Стабильность", "best_round": 2, "winrate": 78.5, "elo": 1850, "aliases": ["Джейсон"]},
    
    "Райдэн": {"role": "Палач-Затяжной", "best_round": 3, "winrate": 76.2, "elo": 1820, "aliases": ["Raiden", "Райден"]},
    "Raiden": {"role": "Палач-Затяжной", "best_round": 3, "winrate": 76.2, "elo": 1820, "aliases": ["Райдэн"]},
    
    "Рептилия": {"role": "Палач-Ночной", "best_round": 2, "winrate": 74.8, "elo": 1780, "aliases": ["Reptile", "Рептайл"]},
    "Reptile": {"role": "Палач-Ночной", "best_round": 2, "winrate": 74.8, "elo": 1780, "aliases": ["Рептилия"]},
    
    "Триборг": {"role": "Палач-Универсал", "best_round": 2, "winrate": 79.1, "elo": 1860, "aliases": ["Triborg", "Триборг Сектор"]},
    "Triborg": {"role": "Палач-Универсал", "best_round": 2, "winrate": 79.1, "elo": 1860, "aliases": ["Триборг"]},
    
    "Милина": {"role": "Палач-Скорость", "best_round": 1, "winrate": 77.3, "elo": 1810, "aliases": ["Mileena", "Милена"]},
    "Mileena": {"role": "Палач-Скорость", "best_round": 1, "winrate": 77.3, "elo": 1810, "aliases": ["Милина"]},
    
    "Шиннок": {"role": "Палач-Контроль", "best_round": 2, "winrate": 73.5, "elo": 1760, "aliases": ["Shinnok", "Шинок"]},
    "Shinnok": {"role": "Палач-Контроль", "best_round": 2, "winrate": 73.5, "elo": 1760, "aliases": ["Шиннок"]},
    
    "Коталь Кан": {"role": "Палач-Мощь", "best_round": 2, "winrate": 75.1, "elo": 1790, "aliases": ["Kotal Kahn", "Коталь"]},
    "Kotal Kahn": {"role": "Палач-Мощь", "best_round": 2, "winrate": 75.1, "elo": 1790, "aliases": ["Коталь Кан"]},
    "Коталь": {"role": "Палач-Мощь", "best_round": 2, "winrate": 75.1, "elo": 1790, "aliases": ["Kotal"]},
    
    "Геррас": {"role": "Палач-Босс", "best_round": 2, "winrate": 80.2, "elo": 1880, "aliases": ["Geras", "Герас"]},
    "Geras": {"role": "Палач-Босс", "best_round": 2, "winrate": 80.2, "elo": 1880, "aliases": ["Геррас"]},
    
    "Синдел": {"role": "Палач-Вопль", "best_round": 1, "winrate": 74.8, "elo": 1780, "aliases": ["Sindel", "Синдель"]},
    "Sindel": {"role": "Палач-Вопль", "best_round": 1, "winrate": 74.8, "elo": 1780, "aliases": ["Синдел"]},
    
    "Ночной Волк": {"role": "Палач-Шаман", "best_round": 3, "winrate": 72.9, "elo": 1750, "aliases": ["Nightwolf", "Найтвульф"]},
    "Nightwolf": {"role": "Палач-Шаман", "best_round": 3, "winrate": 72.9, "elo": 1750, "aliases": ["Ночной Волк"]},
    
    "Спавн": {"role": "Палач-Ад", "best_round": 2, "winrate": 78.9, "elo": 1850, "aliases": ["Spawn", "Споун"]},
    "Spawn": {"role": "Палач-Ад", "best_round": 2, "winrate": 78.9, "elo": 1850, "aliases": ["Спавн"]},
    
    "Терминатор": {"role": "Палач-Машина", "best_round": 2, "winrate": 77.5, "elo": 1820, "aliases": ["Terminator", "T-800"]},
    "Terminator": {"role": "Палач-Машина", "best_round": 2, "winrate": 77.5, "elo": 1820, "aliases": ["Терминатор"]},
    
    "Робокоп": {"role": "Палач-Закон", "best_round": 2, "winrate": 76.8, "elo": 1800, "aliases": ["RoboCop"]},
    "RoboCop": {"role": "Палач-Закон", "best_round": 2, "winrate": 76.8, "elo": 1800, "aliases": ["Робокоп"]},
    
    "Рэмбо": {"role": "Палач-Ветеран", "best_round": 3, "winrate": 75.4, "elo": 1790, "aliases": ["Rambo", "Рембо"]},
    "Rambo": {"role": "Палач-Ветеран", "best_round": 3, "winrate": 75.4, "elo": 1790, "aliases": ["Рэмбо"]},
}

# === ДОНОРЫ (Те, на ком чаще всего делают добивания) ===
DONORS = {
    "Соня Блейд": {"best_for": ["Джейсон", "Милина", "Спавн"], "donor_rate": 72.5, "elo": 1550, "aliases": ["Sonya Blade", "Соня", "Sonya"]},
    "Sonya Blade": {"best_for": ["Джейсон", "Милина", "Спавн"], "donor_rate": 72.5, "elo": 1550, "aliases": ["Соня Блейд"]},
    "Соня": {"best_for": ["Джейсон", "Милина", "Спавн"], "donor_rate": 72.5, "elo": 1550, "aliases": ["Sonya"]},
    "Sonya": {"best_for": ["Джейсон", "Милина", "Спавн"], "donor_rate": 72.5, "elo": 1550, "aliases": ["Соня"]},
    
    "Джакс": {"best_for": ["Триборг", "Райдэн", "Терминатор"], "donor_rate": 68.3, "elo": 1580, "aliases": ["Jax", "Джакс Бриггс"]},
    "Jax": {"best_for": ["Триборг", "Райдэн", "Терминатор"], "donor_rate": 68.3, "elo": 1580, "aliases": ["Джакс"]},
    
    "Кэсси Кейдж": {"best_for": ["Все Палачи"], "donor_rate": 70.1, "elo": 1560, "aliases": ["Cassie Cage", "Кэсси", "Cassie"]},
    "Cassie Cage": {"best_for": ["Все Палачи"], "donor_rate": 70.1, "elo": 1560, "aliases": ["Кэсси Кейдж"]},
    
    "Ди'Вора": {"best_for": ["Сухие матчи"], "donor_rate": 65.4, "elo": 1520, "aliases": ["D'Vorah", "ДиВора", "DVorah"]},
    "D'Vorah": {"best_for": ["Сухие матчи"], "donor_rate": 65.4, "elo": 1520, "aliases": ["Ди'Вора", "ДиВора"]},
    
    "Китана": {"best_for": ["Милина", "Синдел"], "donor_rate": 66.8, "elo": 1530, "aliases": ["Kitana"]},
    "Kitana": {"best_for": ["Милина", "Синдел"], "donor_rate": 66.8, "elo": 1530, "aliases": ["Китана"]},
    
    "Джейд": {"best_for": ["Рептилия"], "donor_rate": 64.2, "elo": 1510, "aliases": ["Jade"]},
    "Jade": {"best_for": ["Рептилия"], "donor_rate": 64.2, "elo": 1510, "aliases": ["Джейд"]},
    
    "Жаклин Бриггс": {"best_for": ["Триборг"], "donor_rate": 67.5, "elo": 1570, "aliases": ["Jacqui Briggs", "Жаклин", "Jacqui"]},
    "Jacqui Briggs": {"best_for": ["Триборг"], "donor_rate": 67.5, "elo": 1570, "aliases": ["Жаклин Бриггс"]},
    
    "Кунг Лао": {"best_for": ["Райдэн"], "donor_rate": 63.8, "elo": 1500, "aliases": ["Kung Lao", "КунгЛао"]},
    "Kung Lao": {"best_for": ["Райдэн"], "donor_rate": 63.8, "elo": 1500, "aliases": ["Кунг Лао"]},
    
    "Кунг Джин": {"best_for": ["Шиннок"], "donor_rate": 62.5, "elo": 1490, "aliases": ["Kung Jin", "КунгДжин"]},
    "Kung Jin": {"best_for": ["Шиннок"], "donor_rate": 62.5, "elo": 1490, "aliases": ["Кунг Джин"]},
    
    "Такеда Такахаши": {"best_for": ["Джейсон"], "donor_rate": 68.9, "elo": 1580, "aliases": ["Takeda Takahashi", "Такеда", "Takeda"]},
    "Takeda": {"best_for": ["Джейсон"], "donor_rate": 68.9, "elo": 1580, "aliases": ["Такеда"]},
    
    "Кенши": {"best_for": ["Райдэн"], "donor_rate": 65.7, "elo": 1540, "aliases": ["Kenshi"]},
    "Kenshi": {"best_for": ["Райдэн"], "donor_rate": 65.7, "elo": 1540, "aliases": ["Кенши"]},
    
    "Эррон Блэк": {"best_for": ["Терминатор"], "donor_rate": 64.3, "elo": 1520, "aliases": ["Erron Black", "Эррон", "Erron"]},
    "Erron Black": {"best_for": ["Терминатор"], "donor_rate": 64.3, "elo": 1520, "aliases": ["Эррон Блэк"]},
}

# === СЛИВЩИКИ (Те, кто ломают алгоритм - опасны!) ===
UPSETTERS = {
    "Чужой": {"danger_level": "КРИТИЧЕСКИЙ", "note": "Самый опасный аутсайдер!", "elo": 1600, "aliases": ["Alien", "Ксеноморф", "Xenomorph"]},
    "Alien": {"danger_level": "КРИТИЧЕСКИЙ", "note": "Самый опасный аутсайдер!", "elo": 1600, "aliases": ["Чужой"]},
    
    "Тремор": {"danger_level": "ВЫСОКИЙ", "note": "Ломает серии фаталити", "elo": 1620, "aliases": ["Tremor"]},
    "Tremor": {"danger_level": "ВЫСОКИЙ", "note": "Ломает серии фаталити", "elo": 1620, "aliases": ["Тремор"]},
    
    "Лю Кан": {"danger_level": "СРЕДНИЙ", "note": "Может выиграть 3:0 будучи аутсайдером", "elo": 1650, "aliases": ["Liu Kang", "ЛюКан"]},
    "Liu Kang": {"danger_level": "СРЕДНИЙ", "note": "Может выиграть 3:0 будучи аутсайдером", "elo": 1650, "aliases": ["Лю Кан"]},
    
    "Скорпион": {"danger_level": "СРЕДНИЙ", "note": "Непредсказуем, часто ломает серии", "elo": 1680, "aliases": ["Scorpion", "Скорп"]},
    "Scorpion": {"danger_level": "СРЕДНИЙ", "note": "Непредсказуем, часто ломает серии", "elo": 1680, "aliases": ["Скорпион"]},
    
    "Саб-Зиро": {"danger_level": "СРЕДНИЙ", "note": "Может выиграть без добиваний", "elo": 1670, "aliases": ["Sub-Zero", "СабЗиро", "Sub Zero"]},
    "Sub-Zero": {"danger_level": "СРЕДНИЙ", "note": "Может выиграть без добиваний", "elo": 1670, "aliases": ["Саб-Зиро"]},
    
    "Ферра и Торр": {"danger_level": "ВЫСОКИЙ", "note": "Непредсказуемый тандем", "elo": 1610, "aliases": ["Ferra & Torr", "Ferra Torr", "Ферра Торр"]},
    "Ferra & Torr": {"danger_level": "ВЫСОКИЙ", "note": "Непредсказуемый тандем", "elo": 1610, "aliases": ["Ферра и Торр"]},
    
    "Кано": {"danger_level": "СРЕДНИЙ", "note": "Хаотичный стиль, ломает паттерны", "elo": 1630, "aliases": ["Kano"]},
    "Kano": {"danger_level": "СРЕДНИЙ", "note": "Хаотичный стиль, ломает паттерны", "elo": 1630, "aliases": ["Кано"]},
}

# === НЕЙТРАЛЬНЫЕ ===
NEUTRAL = {
    "Кратос": {"note": "PlayStation exclusive", "elo": 1700, "aliases": ["Kratos"]},
    "Kratos": {"note": "PlayStation exclusive", "elo": 1700, "aliases": ["Кратос"]},
    
    "Хищник": {"note": "Guest character", "elo": 1690, "aliases": ["Predator", "Предатор"]},
    "Predator": {"note": "Guest character", "elo": 1690, "aliases": ["Хищник"]},
    
    "Горо": {"note": "Boss character", "elo": 1750, "aliases": ["Goro"]},
    "Goro": {"note": "Boss character", "elo": 1750, "aliases": ["Горо"]},
    
    "Таня": {"note": "DLC character", "elo": 1640, "aliases": ["Tanya"]},
    "Tanya": {"note": "DLC character", "elo": 1640, "aliases": ["Таня"]},
}


def get_character_type(name: str) -> tuple:
    """Определяет тип персонажа по имени"""
    name_clean = name.strip()
    
    for char_name, info in EXECUTORS.items():
        if name_clean.lower() == char_name.lower():
            return ("EXECUTOR", info)
        if 'aliases' in info:
            for alias in info['aliases']:
                if name_clean.lower() == alias.lower():
                    return ("EXECUTOR", info)
    
    for char_name, info in DONORS.items():
        if name_clean.lower() == char_name.lower():
            return ("DONOR", info)
        if 'aliases' in info:
            for alias in info['aliases']:
                if name_clean.lower() == alias.lower():
                    return ("DONOR", info)
    
    for char_name, info in UPSETTERS.items():
        if name_clean.lower() == char_name.lower():
            return ("UPSETTER", info)
        if 'aliases' in info:
            for alias in info['aliases']:
                if name_clean.lower() == alias.lower():
                    return ("UPSETTER", info)
    
    for char_name, info in NEUTRAL.items():
        if name_clean.lower() == char_name.lower():
            return ("NEUTRAL", info)
        if 'aliases' in info:
            for alias in info['aliases']:
                if name_clean.lower() == alias.lower():
                    return ("NEUTRAL", info)
    
    return ("UNKNOWN", {})


def get_character_elo(name: str) -> int:
    """Возвращает ELO-рейтинг персонажа"""
    char_type, info = get_character_type(name)
    return info.get('elo', 1600)  # Default ELO


def get_all_aliases() -> set:
    """Возвращает все известные алиасы"""
    aliases = set()
    
    for db in [EXECUTORS, DONORS, UPSETTERS, NEUTRAL]:
        for name, info in db.items():
            aliases.add(name)
            if 'aliases' in info:
                aliases.update(info['aliases'])
    
    return aliases


ALL_CHARACTERS = list(EXECUTORS.keys()) + list(DONORS.keys()) + list(UPSETTERS.keys()) + list(NEUTRAL.keys())
