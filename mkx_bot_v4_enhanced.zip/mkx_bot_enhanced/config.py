"""
Конфигурация бота MKX Strategy v4.0 (Enhanced)
Улучшенная версия с Kelly Criterion, Online ML, Redis Cache, PDF Reports
"""

import os
from dotenv import load_dotenv

# Загружаем переменные окружения
load_dotenv()

# === TELEGRAM API CREDENTIALS ===
API_ID = int(os.getenv('TELEGRAM_API_ID', 0))
API_HASH = os.getenv('TELEGRAM_API_HASH', '')
PHONE_NUMBER = os.getenv('PHONE_NUMBER', '')

# === BOT TOKEN ===
BOT_TOKEN = os.getenv('BOT_TOKEN', '')

# === CHANNELS ===
SOURCE_CHANNEL = os.getenv('SOURCE_CHANNEL', 'statamk10')
TARGET_GROUP_ID = int(os.getenv('TARGET_GROUP_ID', 0))
ADMIN_USER_ID = int(os.getenv('ADMIN_USER_ID', 0))

# === REDIS CONFIG ===
REDIS_HOST = os.getenv('REDIS_HOST', 'localhost')
REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))
REDIS_DB = int(os.getenv('REDIS_DB', 0))
REDIS_PASSWORD = os.getenv('REDIS_PASSWORD', None)

# === BANKROLL MANAGEMENT ===
INITIAL_BANKROLL = float(os.getenv('INITIAL_BANKROLL', 10000))
MAX_DAILY_LOSS_PERCENT = float(os.getenv('MAX_DAILY_LOSS_PERCENT', 20))
MAX_BET_PERCENT = float(os.getenv('MAX_BET_PERCENT', 10))

# === KELLY CRITERION SETTINGS ===
KELLY_FRACTION = float(os.getenv('KELLY_FRACTION', 0.25))  # Fractional Kelly (25%)
MIN_KELLY_BET = float(os.getenv('MIN_KELLY_BET', 500))     # Минимальная ставка
MAX_KELLY_BET = float(os.getenv('MAX_KELLY_BET', 5000))    # Максимальная ставка

# === СТРАТЕГИЯ v4.0: ЗОЛОТЫЕ МИНУТЫ ===
GOLDEN_MINUTES = [
    "00:10", "00:15", "00:20", "00:25", "00:30", "00:45",
    "01:25", "01:50", "05:55", "07:50", "12:50", "13:20", "14:50"
]

# === СТРАТЕГИЯ v4.0: МЕРТВЫЕ МИНУТЫ ===
DEAD_MINUTES = [
    "03:00", "03:30", "04:00", "04:30",
    "12:10", "12:40", "13:15",
    "23:50", "23:55", "23:59"
]

# === МАТЕМАТИКА ===
IDEAL_FATality_KF_RANGE = (2.1, 2.8)
MIN_FATality_KF = 1.5

# Адаптивная прогрессия (базовая)
BET_PROGRESSION = [1000, 2200, 4800]
MAX_DOGON_ROUND = 3

# === ПОРОГИ УВЕРЕННОСТИ ===
CONFIDENCE_THRESHOLDS = {
    'strong': 75,
    'medium': 55,
    'weak': 35
}

# === НАСТРОЙКИ МОНИТОРИНГА ===
CHECK_INTERVAL = 5
MATCH_WAIT_TIME = 20

# === ФАЙЛЫ ===
STATE_FILE = "bot_state.json"
DB_FILE = "mkx_stats.db"
BANKROLL_FILE = "bankroll.json"
METRICS_FILE = "metrics.json"
LOG_FILE = "mkx_bot.log"
REPORTS_DIR = "reports"
ML_MODEL_FILE = "ml_model.pkl"

# === LOGGING ===
LOG_LEVEL = "INFO"

# === RETRY ===
MAX_RETRIES = 3
RETRY_DELAY = 2

# === ML НАСТРОЙКИ ===
ML_MIN_SAMPLES = 50
ML_ONLINE_LEARNING = True  # Включить онлайн-обучение
ML_RETRAIN_INTERVAL = 100  # Переобучение каждые N матчей

ML_FEATURES = [
    'executor_strength',
    'donor_weakness',
    'time_pattern_score',
    'recent_wave_factor',
    'odds_value',
    'confidence_score',
    'elo_diff',
    'head_to_head',
    'momentum_p1',
    'momentum_p2'
]

# === PDF REPORTS ===
PDF_REPORT_ENABLED = True
PDF_DAILY_REPORT_HOUR = 23
PDF_DAILY_REPORT_MINUTE = 59
PDF_WEEKLY_REPORT_DAY = 6  # Воскресенье

# === ALERTS ===
ALERT_HIGH_CONFIDENCE = 85
ALERT_BIG_LOSS_THRESHOLD = 2000
ALERT_DAILY_GOAL = 2000

# === ВАЛИДАЦИЯ ===
def validate_config():
    """Проверяет, что все необходимые переменные заданы"""
    required = [
        ('TELEGRAM_API_ID', API_ID),
        ('TELEGRAM_API_HASH', API_HASH),
        ('BOT_TOKEN', BOT_TOKEN),
        ('TARGET_GROUP_ID', TARGET_GROUP_ID),
    ]
    
    missing = [name for name, value in required if not value]
    
    if missing:
        raise ValueError(f"Отсутствуют обязательные переменные окружения: {', '.join(missing)}")
    
    return True
