"""
MKX Strategy Bot v4.0 - Enhanced
Улучшенная версия с:
- Kelly Criterion для ставок
- Online ML с ансамблем моделей
- Redis кэширование
- PDF отчеты
"""

import asyncio
import json
import logging
import re
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from telethon import TelegramClient, events
from telethon.tl.types import PeerChannel, PeerChat
import aiohttp

import config
from characters_db import get_character_type, get_character_elo, EXECUTORS, DONORS, UPSETTERS
from database import async_db
from kelly_manager import kelly_manager
from ml_enhanced import enhanced_ml
from cache_manager import cache
from pdf_reporter import pdf_reporter, ReportData

# Проверка конфигурации
config.validate_config()

# Настройка логирования
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(config.LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


# === DATA CLASSES ===

@dataclass
class MatchData:
    """Структура данных матча"""
    match_id: str
    league: str
    timestamp: datetime
    player1: str
    player2: str
    p1_match_odds: float
    p2_match_odds: float
    p1_round_odds: float
    p2_round_odds: float
    fatality_odds: float
    brutality_odds: float
    no_finish_odds: float
    time_stats: Dict[str, Tuple[float, float]]
    raw_text: str
    confidence_score: int = 0
    analyzed: bool = False
    analysis_result: Optional[str] = None
    bet_recommendation: Optional[str] = None


@dataclass
class RoundResult:
    """Результат раунда"""
    round_num: int
    winner: str
    finish_type: str
    time_seconds: int
    raw_line: str


@dataclass
class TrackedMatch:
    """Отслеживаемый матч"""
    match_data: MatchData
    sent_analysis_id: Optional[int] = None
    rounds_completed: List[RoundResult] = None
    bet_won: Optional[bool] = None
    won_in_round: Optional[int] = None
    status: str = "pending"
    bet_type: Optional[str] = None
    bet_amount: float = 0
    bet_id: Optional[int] = None
    analysis_text: str = ""
    kelly_details: Dict = None
    ml_details: Dict = None
    
    def __post_init__(self):
        if self.rounds_completed is None:
            self.rounds_completed = []


# === TELEGRAM BOT API ===

class TelegramBotAPI:
    """Класс для работы с Bot API"""
    
    def __init__(self, token: str):
        self.token = token
        self.base_url = f"https://api.telegram.org/bot{token}"
    
    async def send_message(self, chat_id: int, text: str, parse_mode: str = "HTML") -> Optional[int]:
        """Отправляет сообщение"""
        url = f"{self.base_url}/sendMessage"
        payload = {"chat_id": chat_id, "text": text, "parse_mode": parse_mode}
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, timeout=10) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data["result"]["message_id"]
        except Exception as e:
            logger.error(f"Ошибка отправки сообщения: {e}")
        return None
    
    async def edit_message(self, chat_id: int, message_id: int, text: str, 
                          parse_mode: str = "HTML") -> bool:
        """Редактирует сообщение"""
        url = f"{self.base_url}/editMessageText"
        payload = {"chat_id": chat_id, "message_id": message_id, "text": text, "parse_mode": parse_mode}
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, timeout=10) as response:
                    return response.status == 200
        except Exception as e:
            logger.error(f"Ошибка редактирования сообщения: {e}")
        return False
    
    async def send_document(self, chat_id: int, document_path: str, caption: str = "") -> bool:
        """Отправляет документ"""
        try:
            url = f"{self.base_url}/sendDocument"
            async with aiohttp.ClientSession() as session:
                with open(document_path, 'rb') as f:
                    data = aiohttp.FormData()
                    data.add_field('chat_id', str(chat_id))
                    data.add_field('document', f, filename=os.path.basename(document_path))
                    data.add_field('caption', caption)
                    async with session.post(url, data=data, timeout=30) as response:
                        return response.status == 200
        except Exception as e:
            logger.error(f"Ошибка отправки документа: {e}")
        return False


# === PARSER ===

class MKXParser:
    """Парсер данных MKX"""
    
    KNOWN_NAMES = [
        "Jax", "Sonya Blade", "Cassie Cage", "Kung Jin", "Kung Lao",
        "Kitana", "Mileena", "Scorpion", "Sub-Zero", "Liu Kang",
        "Raiden", "Kano", "D'Vorah", "Takeda Takahashi", "Kenshi",
        "Erron Black", "Jacqui Briggs", "Tanya", "Reptile", "Ermac",
        "Ferra & Torr", "Kotal Kahn", "Shinnok", "Cetrion", "Geras",
        "Kollector", "Nightwolf", "Sindel", "Spawn", "Terminator",
        "Joker", "RoboCop", "Rambo", "Sheeva", "Fujin", "Rain",
        "Jason", "Predator", "Alien", "Tremor", "Triborg", "Goro",
        "Джейсон", "Райдэн", "Рептилия", "Триборг", "Милина", "Шиннок",
        "Коталь Кан", "Геррас", "Синдел", "Ночной Волк", "Спавн",
        "Терминатор", "Робокоп", "Рэмбо", "Соня Блейд", "Джакс",
        "Кэсси Кейдж", "Ди'Вора", "Китана", "Джейд", "Жаклин",
        "Кунг Лао", "Кунг Джин", "Такеда", "Кенши", "Эррон Блэк",
        "Чужой", "Тремор", "Лю Кан", "Скорпион", "Саб-Зиро", "Кано"
    ]
    
    @staticmethod
    def extract_player_names(text: str) -> Optional[Tuple[str, str]]:
        """Извлекает имена персонажей"""
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        
        for line in lines:
            if any(marker in line for marker in ['|', 'P1m', 'P2m', 'FBR', 'FYes', 'TimeStat']):
                continue
            
            for separator in [' - ', ' VS ', ' vs ', ' – ', ' — ']:
                if separator in line:
                    parts = line.split(separator, 1)
                    if len(parts) == 2:
                        p1 = parts[0].strip()
                        p2 = parts[1].strip()
                        
                        if not any(c.isdigit() for c in p1) and not any(c.isdigit() for c in p2):
                            if MKXParser._is_valid_name(p1) and MKXParser._is_valid_name(p2):
                                return (p1, p2)
        
        return None
    
    @staticmethod
    def _is_valid_name(name: str) -> bool:
        """Проверяет имя персонажа"""
        name_lower = name.lower()
        
        for known in MKXParser.KNOWN_NAMES:
            if name_lower == known.lower():
                return True
            if known.lower() in name_lower or name_lower in known.lower():
                return True
        
        char_type, _ = get_character_type(name)
        if char_type != "UNKNOWN":
            return True
        
        return re.match(r'^[\w\s\-\'&]+$', name) is not None
    
    @staticmethod
    def parse_match_message(text: str) -> Optional[MatchData]:
        """Парсит сообщение с данными матча"""
        try:
            lines = [line.strip() for line in text.split('\n') if line.strip()]
            
            # Парсим время и ID
            header_match = re.search(r'(\d{2}:\d{2})\s+(\d{2}-\d{2}-\d{4})\s+#(N\d+)', lines[0])
            if not header_match:
                return None
            
            time_str, date_str, match_id = header_match.groups()
            timestamp = datetime.strptime(f"{date_str} {time_str}", "%d-%m-%Y %H:%M")
            
            # Имена персонажей
            names = MKXParser.extract_player_names(text)
            if not names:
                return None
            
            player1, player2 = names
            
            # Коэффициенты
            p1_match_odds = p2_match_odds = 0
            match_odds = re.search(r'P1m\|P2m[^\d]+(\d+(?:\.\d+)?)[^\d]+(\d+(?:\.\d+)?)', text, re.IGNORECASE)
            if match_odds:
                p1_match_odds = float(match_odds.group(1))
                p2_match_odds = float(match_odds.group(2))
            
            fatality_odds = brutality_odds = no_finish_odds = 0
            fbr_match = re.search(r'FBR[^\d]+(\d+(?:\.\d+)?)[^\d]+(\d+(?:\.\d+)?)[^\d]+(\d+(?:\.\d+)?)', text, re.IGNORECASE)
            if fbr_match:
                fatality_odds = float(fbr_match.group(1))
                brutality_odds = float(fbr_match.group(2))
                no_finish_odds = float(fbr_match.group(3))
            
            return MatchData(
                match_id=match_id,
                league="L1",
                timestamp=timestamp,
                player1=player1,
                player2=player2,
                p1_match_odds=p1_match_odds,
                p2_match_odds=p2_match_odds,
                p1_round_odds=0,
                p2_round_odds=0,
                fatality_odds=fatality_odds,
                brutality_odds=brutality_odds,
                no_finish_odds=no_finish_odds,
                time_stats={},
                raw_text=text
            )
            
        except Exception as e:
            logger.error(f"Ошибка парсинга: {e}")
            return None


# === ANALYZER ===

class MKXAnalyzer:
    """Анализатор матчей"""
    
    def __init__(self):
        self.db = async_db
    
    async def analyze_match(self, match: MatchData) -> Tuple[str, str, int, Dict]:
        """Анализирует матч"""
        analysis_parts = []
        confidence_score = 0
        details = {
            'bet_type': None,
            'target_round': None,
            'stop_round': 4,
            'ml_probability': 0,
            'ml_recommendation': 'UNKNOWN',
            'wave_streak': 0,
            'consecutive_losses': kelly_manager.state.consecutive_losses
        }
        
        match_time = match.timestamp.strftime("%H:%M")
        
        # Проверка на мертвые минуты
        if match_time in config.DEAD_MINUTES:
            analysis_parts.append(f"⚠️ МЕРТВАЯ МИНУТА ({match_time}) - НЕ СТАВИТЬ!")
            return "\n".join(analysis_parts), "🔴 ПРОПУСК", 0, details
        
        # Золотые минуты
        is_golden = match_time in config.GOLDEN_MINUTES
        if is_golden:
            analysis_parts.append(f"✨ ЗОЛОТАЯ МИНУТА ({match_time})")
            confidence_score += 25
        
        # Проверка персонажей
        p1_type, p1_info = get_character_type(match.player1)
        p2_type, p2_info = get_character_type(match.player2)
        
        # ELO разница
        p1_elo = get_character_elo(match.player1)
        p2_elo = get_character_elo(match.player2)
        elo_diff = p1_elo - p2_elo
        
        if elo_diff > 100:
            analysis_parts.append(f"📈 ELO преимущество: +{elo_diff}")
            confidence_score += 10
        
        # Сливщики
        if p2_type == "UPSETTER":
            analysis_parts.append(f"🚨 ОПАСНОСТЬ: {match.player2} - Сливщик!")
            confidence_score -= 50
        
        if p1_type == "EXECUTOR" and p2_type == "DONOR":
            executor_info = EXECUTORS.get(match.player1, p1_info)
            donor_info = DONORS.get(match.player2, p2_info)
            best_round = executor_info.get('best_round', 2)
            
            analysis_parts.append(f"🎯 ИДЕАЛЬНАЯ КОМБИНАЦИЯ!")
            analysis_parts.append(f"   Палач: {match.player1} (winrate: {executor_info.get('winrate', 70)}%)")
            analysis_parts.append(f"   Донор: {match.player2} (donor_rate: {donor_info.get('donor_rate', 65)}%)")
            analysis_parts.append(f"   Лучший раунд: {best_round}")
            
            details['bet_type'] = 'fatality'
            details['target_round'] = best_round
            confidence_score += 35
        
        elif p1_type == "EXECUTOR":
            executor_info = EXECUTORS.get(match.player1, p1_info)
            best_round = executor_info.get('best_round', 2)
            
            analysis_parts.append(f"✅ Палач слева: {match.player1}")
            details['bet_type'] = 'fatality'
            details['target_round'] = best_round
            confidence_score += 20
        
        # Коэффициенты
        if match.fatality_odds > 0:
            if config.IDEAL_FATality_KF_RANGE[0] <= match.fatality_odds <= config.IDEAL_FATality_KF_RANGE[1]:
                analysis_parts.append(f"💎 ИДЕАЛЬНЫЙ КФ: {match.fatality_odds}")
                confidence_score += 15
            elif match.fatality_odds >= config.MIN_FATality_KF:
                analysis_parts.append(f"✅ Допустимый КФ: {match.fatality_odds}")
                confidence_score += 10
        
        # ML Предсказание
        try:
            ml_prob, ml_rec, ml_details = enhanced_ml.predict(match, {
                'confidence_score': confidence_score,
                'consecutive_losses': kelly_manager.state.consecutive_losses,
                'wave_streak': 0
            })
            details['ml_probability'] = ml_prob
            details['ml_recommendation'] = ml_rec
            details['ml_details'] = ml_details
            
            analysis_parts.append(f"🤖 ML Вероятность: {ml_prob:.1f}% ({ml_rec})")
            
            if ml_rec == "STRONG":
                confidence_score += 10
            elif ml_rec == "WEAK":
                confidence_score -= 10
        except Exception as e:
            logger.error(f"Ошибка ML: {e}")
        
        # Kelly Criterion
        if details['bet_type'] and match.fatality_odds > 0:
            bet_amount, kelly_details = kelly_manager.get_bet_for_match(
                confidence_score, match.fatality_odds, kelly_manager.state.current_dogon_step
            )
            details['recommended_amount'] = bet_amount
            details['kelly_details'] = kelly_details
            analysis_parts.append(f"\n💰 Kelly ставка: {bet_amount:.0f} руб.")
            analysis_parts.append(f"   EV: {kelly_details.get('expected_value', 0):+.1f}%")
        
        # Финальное решение
        if confidence_score >= config.CONFIDENCE_THRESHOLDS['strong']:
            bet_recommendation = "🟢 СИЛЬНЫЙ СИГНАЛ"
            if details['bet_type'] and details['target_round']:
                bet_recommendation += f" | Fatality в {details['target_round']} раунде"
        elif confidence_score >= config.CONFIDENCE_THRESHOLDS['medium']:
            bet_recommendation = "🟡 СРЕДНИЙ СИГНАЛ"
        elif confidence_score >= config.CONFIDENCE_THRESHOLDS['weak']:
            bet_recommendation = "🟠 СЛАБЫЙ СИГНАЛ"
        else:
            bet_recommendation = "🔴 ПРОПУСК"
        
        analysis_parts.append(f"\n📊 Уверенность: {confidence_score}%")
        analysis_parts.append(f"💡 Рекомендация: {bet_recommendation}")
        
        return "\n".join(analysis_parts), bet_recommendation, confidence_score, details


# === MAIN BOT ===

class MKXBot:
    """Основной класс бота v4.0"""
    
    def __init__(self):
        self.client = TelegramClient('mkx_session', config.API_ID, config.API_HASH)
        self.bot_api = TelegramBotAPI(config.BOT_TOKEN)
        self.parser = MKXParser()
        self.analyzer = MKXAnalyzer()
        self.tracked_matches: Dict[str, TrackedMatch] = {}
        self.running = True
    
    async def start(self):
        """Запускает бота"""
        print("=" * 60)
        print("🎮 MKX STRATEGY BOT v4.0 ENHANCED")
        print("=" * 60)
        print()
        print("✨ Новые функции:")
        print("   • Kelly Criterion для ставок")
        print("   • Online ML с ансамблем")
        print("   • Redis кэширование")
        print("   • PDF отчеты")
        print()
        
        # Инициализация БД
        await async_db.init()
        
        # Проверка кэша
        cache_stats = await cache.get_stats()
        print(f"📦 Кэш: {'включен' if cache_stats['enabled'] else 'отключен'}")
        
        # Проверка Kelly
        kelly_stats = kelly_manager.get_stats()
        print(f"💰 Kelly Bankroll: {kelly_stats['current_balance']:.2f} руб.")
        print(f"📈 Kelly ROI: {kelly_stats['roi_percent']:.1f}%")
        print()
        
        await self.client.start(phone=config.PHONE_NUMBER)
        logger.info("Бот запущен")
        
        # Регистрация обработчиков
        self.client.add_event_handler(
            self.on_new_message,
            events.NewMessage(chats=config.SOURCE_CHANNEL)
        )
        
        print(f"✅ Мониторинг канала @{config.SOURCE_CHANNEL}")
        print(f"✅ Отправка анализа в группу {config.TARGET_GROUP_ID}")
        print()
        
        # Фоновые задачи
        asyncio.create_task(self.daily_stats_loop())
        asyncio.create_task(self.ml_training_loop())
        asyncio.create_task(self.pdf_report_loop())
        
        # Главный цикл
        while self.running:
            try:
                await asyncio.sleep(config.CHECK_INTERVAL)
                await self.check_match_results()
            except Exception as e:
                logger.error(f"Ошибка в главном цикле: {e}")
                await asyncio.sleep(5)
    
    async def on_new_message(self, event):
        """Обработчик новых сообщений"""
        text = event.message.text
        if not text:
            return
        
        # Парсим матч
        match_data = self.parser.parse_match_message(text)
        
        if match_data:
            logger.info(f"🎮 Матч: {match_data.match_id} - {match_data.player1} vs {match_data.player2}")
            await self.process_new_match(match_data)
    
    async def process_new_match(self, match_data: MatchData):
        """Обрабатывает новый матч"""
        # Сохраняем в БД
        await async_db.add_match(match_data)
        
        # Анализируем
        analysis, bet_rec, confidence, details = await self.analyzer.analyze_match(match_data)
        match_data.confidence_score = confidence
        
        # Фильтр по уверенности
        if confidence < 50:
            logger.info(f"Матч {match_data.match_id} пропущен ({confidence}%)")
            return
        
        # Проверяем возможность ставки
        bet_amount = details.get('recommended_amount', 0)
        can_bet, reason = kelly_manager.can_place_bet(bet_amount)
        
        if not can_bet:
            logger.warning(f"Невозможно сделать ставку: {reason}")
            return
        
        # Формируем сообщение
        message = self.format_analysis_message(match_data, analysis, bet_rec, confidence, details)
        
        # Отправляем
        msg_id = await self.bot_api.send_message(config.TARGET_GROUP_ID, message)
        
        if msg_id:
            # Регистрируем ставку
            actual_bet = kelly_manager.place_bet(bet_amount)
            
            # Сохраняем в БД
            bet_id = await async_db.add_bet(
                match_id=match_data.match_id,
                bet_type=details.get('bet_type'),
                predicted_round=details.get('target_round'),
                amount=actual_bet,
                odds=match_data.fatality_odds,
                dogon_step=kelly_manager.state.current_dogon_step,
                kelly_fraction=details.get('kelly_details', {}).get('adjusted_fraction')
            )
            
            # Отслеживаем
            tracked = TrackedMatch(
                match_data=match_data,
                sent_analysis_id=msg_id,
                bet_type=details.get('bet_type'),
                bet_amount=actual_bet,
                bet_id=bet_id,
                analysis_text=analysis,
                kelly_details=details.get('kelly_details'),
                ml_details=details.get('ml_details')
            )
            self.tracked_matches[match_data.match_id] = tracked
            
            logger.info(f"✅ Анализ отправлен, ставка: {actual_bet}")
    
    def format_analysis_message(self, match: MatchData, analysis: str, bet_rec: str, 
                                confidence: int, details: Dict) -> str:
        """Формирует сообщение с анализом"""
        
        p1_type, _ = get_character_type(match.player1)
        p2_type, _ = get_character_type(match.player2)
        
        p1_icon = "🔪" if p1_type == "EXECUTOR" else "💀" if p1_type == "DONOR" else "⚡" if p2_type == "UPSETTER" else "👤"
        p2_icon = "🔪" if p2_type == "EXECUTOR" else "💀" if p2_type == "DONOR" else "⚡" if p2_type == "UPSETTER" else "👤"
        
        bet_amount = details.get('recommended_amount', 0)
        kelly_details = details.get('kelly_details', {})
        ml_prob = details.get('ml_probability', 0)
        
        lines = [
            f"🎮 <b>НОВЫЙ МАТЧ</b> #{match.match_id}",
            f"",
            f"{p1_icon} <b>{match.player1}</b> vs {p2_icon} <b>{match.player2}</b>",
            f"🕐 Время: {match.timestamp.strftime('%H:%M %d-%m-%Y')}",
            f"",
            f"📈 <b>Коэффициенты:</b>",
            f"   F | B | R: {match.fatality_odds} | {match.brutality_odds} | {match.no_finish_odds}",
            f"",
            f"📋 <b>АНАЛИЗ:</b>",
            f"{analysis}",
            f"",
            f"🤖 ML Вероятность: {ml_prob:.1f}%",
            f"💰 Ставка (Kelly): {bet_amount:.0f} руб.",
            f"📊 Kelly Fraction: {kelly_details.get('bankroll_used', 0):.1f}% банкролла",
            f"",
            f"⏳ Ожидание результатов..."
        ]
        
        return "\n".join(lines)
    
    async def process_round_results(self, match_id: str, rounds: List[RoundResult]):
        """Обрабатывает результаты раундов"""
        if match_id not in self.tracked_matches:
            return
        
        tracked = self.tracked_matches[match_id]
        tracked.rounds_completed = rounds
        
        # Ищем победный раунд
        won_round = None
        for r in rounds:
            if r.round_num <= 3:
                if tracked.bet_type == 'fatality' and r.finish_type == 'F':
                    won_round = r.round_num
                    break
        
        # Определяем результат
        reached_round_4 = any(r.round_num >= 4 for r in rounds)
        
        if won_round:
            tracked.bet_won = True
            tracked.won_in_round = won_round
            tracked.status = "won"
            
            # Выигрыш
            odds = tracked.match_data.fatality_odds
            profit = kelly_manager.record_win(tracked.bet_amount, odds, won_round)
            
            # ML обучение
            enhanced_ml.record_result(tracked.match_data, {}, True)
            
        elif reached_round_4:
            tracked.bet_won = False
            tracked.status = "lost"
            kelly_manager.record_loss(tracked.bet_amount)
            
            # ML обучение
            enhanced_ml.record_result(tracked.match_data, {}, False)
        
        # Обновляем БД
        await async_db.update_bet_result(
            bet_id=tracked.bet_id,
            result=tracked.status,
            won_in_round=tracked.won_in_round,
            profit=tracked.bet_amount * (tracked.match_data.fatality_odds - 1) if tracked.status == "won" else -tracked.bet_amount
        )
        
        # Обновляем сообщение
        await self.update_analysis_status(tracked)
    
    async def update_analysis_status(self, tracked: TrackedMatch):
        """Обновляет статус в Telegram"""
        if not tracked.sent_analysis_id:
            return
        
        try:
            if tracked.status == "won":
                checkmarks = "✅" * tracked.won_in_round
                profit = tracked.bet_amount * (tracked.match_data.fatality_odds - 1)
                status_text = f"\n\n{checkmarks} <b>СТАВКА ЗАШЛА!</b>\n🎯 Раунд: {tracked.won_in_round}\n💰 Прибыль: +{profit:.0f} руб."
            elif tracked.status == "lost":
                status_text = f"\n\n❌ <b>СТАВКА НЕ ЗАШЛА</b>\n📉 Убыток: -{tracked.bet_amount:.0f} руб."
                next_amount = kelly_manager.get_next_bet_amount()
                if next_amount > tracked.bet_amount:
                    status_text += f"\n🔄 Следующий догон: {next_amount:.0f} руб."
            else:
                return
            
            original_message = self.format_analysis_message(
                tracked.match_data, tracked.analysis_text, "",
                tracked.match_data.confidence_score, {}
            )
            
            new_text = original_message.replace("⏳ Ожидание результатов...", status_text)
            
            await self.bot_api.edit_message(
                config.TARGET_GROUP_ID,
                tracked.sent_analysis_id,
                new_text
            )
            
        except Exception as e:
            logger.error(f"Ошибка обновления статуса: {e}")
    
    async def check_match_results(self):
        """Проверка результатов по таймауту"""
        current_time = datetime.now()
        
        for match_id, tracked in list(self.tracked_matches.items()):
            match_time = tracked.match_data.timestamp
            time_diff = (current_time - match_time).total_seconds() / 60
            
            if time_diff > config.MATCH_WAIT_TIME and tracked.status == "pending":
                tracked.status = "lost"
                kelly_manager.record_loss(tracked.bet_amount)
                
                await async_db.update_bet_result(
                    bet_id=tracked.bet_id,
                    result='lost',
                    profit=-tracked.bet_amount
                )
                
                await self.update_analysis_status(tracked)
                logger.info(f"Матч {match_id} помечен как lost по таймауту")
    
    async def daily_stats_loop(self):
        """Отправка ежедневной статистики"""
        while self.running:
            now = datetime.now()
            if now.hour == 23 and now.minute == 30:
                stats = kelly_manager.get_stats()
                
                message = f"""
📊 <b>ЕЖЕДНЕВНАЯ СТАТИСТИКА</b>

💰 Баланс: {stats['current_balance']:.2f} руб.
📈 Прибыль: {stats['total_profit']:+.2f} руб. (ROI: {stats['roi_percent']:.1f}%)

Ставок: {stats['total_bets']} | ✅ {stats['wins']} | ❌ {stats['losses']}
Винрейт: {stats['winrate']:.1f}%
Просадка: {stats['drawdown']:.1f}%

Kelly Fraction: {config.KELLY_FRACTION * 100:.0f}%
"""
                await self.bot_api.send_message(config.TARGET_GROUP_ID, message)
                
                await asyncio.sleep(60)
            
            await asyncio.sleep(30)
    
    async def ml_training_loop(self):
        """Цикл обучения ML"""
        while self.running:
            try:
                # Получаем данные для обучения
                training_data = await async_db.get_ml_training_data_async(limit=500)
                
                if len(training_data) >= config.ML_MIN_SAMPLES:
                    logger.info(f"Обучение ML на {len(training_data)} записях...")
                    enhanced_ml.train_ensemble(training_data)
                
                # Ждем 1 час
                await asyncio.sleep(3600)
                
            except Exception as e:
                logger.error(f"Ошибка в цикле ML: {e}")
                await asyncio.sleep(300)
    
    async def pdf_report_loop(self):
        """Цикл генерации PDF отчетов"""
        if not config.PDF_REPORT_ENABLED:
            return
        
        while self.running:
            try:
                now = datetime.now()
                
                # Ежедневный отчет
                if now.hour == config.PDF_DAILY_REPORT_HOUR and now.minute == config.PDF_DAILY_REPORT_MINUTE:
                    logger.info("Генерация PDF отчета...")
                    
                    # Получаем данные
                    bet_stats = await async_db.get_bet_stats_async(days=1)
                    hourly_data = await async_db.get_hourly_stats_async(days=1)
                    char_stats = await async_db.get_top_characters_async(limit=10)
                    ml_accuracy = await async_db.get_ml_accuracy_async(days=1)
                    
                    report_data = ReportData(
                        period="daily",
                        start_date=now.replace(hour=0, minute=0, second=0),
                        end_date=now,
                        total_bets=bet_stats.get('total', 0),
                        wins=bet_stats.get('wins', 0),
                        losses=bet_stats.get('losses', 0),
                        profit=bet_stats.get('net_profit', 0),
                        roi=bet_stats.get('roi', 0),
                        winrate=bet_stats.get('winrate', 0),
                        daily_data=[{'date': now, 'profit': bet_stats.get('net_profit', 0)}],
                        hourly_data=hourly_data,
                        character_stats=char_stats,
                        ml_accuracy=ml_accuracy
                    )
                    
                    filepath = pdf_reporter.generate_daily_report(report_data)
                    pdf_reporter.cleanup_charts()
                    
                    if filepath:
                        await self.bot_api.send_document(
                            config.TARGET_GROUP_ID,
                            filepath,
                            caption="📄 Ежедневный отчет"
                        )
                    
                    await asyncio.sleep(60)
                
                await asyncio.sleep(30)
                
            except Exception as e:
                logger.error(f"Ошибка в цикле PDF: {e}")
                await asyncio.sleep(300)


# === MAIN ===

async def main():
    bot = MKXBot()
    await bot.start()


if __name__ == "__main__":
    asyncio.run(main())
