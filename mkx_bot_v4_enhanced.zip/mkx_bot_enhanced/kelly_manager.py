"""
Kelly Criterion Manager для MKX Strategy Bot v4.0
Управление размером ставок по формуле Келли
"""

import json
import logging
from datetime import datetime
from typing import Optional, Tuple, Dict
from dataclasses import dataclass, asdict

import config

logger = logging.getLogger(__name__)


@dataclass
class KellyState:
    """Состояние Kelly-менеджера"""
    current_balance: float
    initial_balance: float
    total_bets: int = 0
    total_wins: int = 0
    total_losses: int = 0
    total_profit: float = 0
    max_balance: float = 0
    consecutive_losses: int = 0
    last_bet_amount: float = 0
    kelly_fraction: float = 0.25


class KellyCriterion:
    """
    Реализация формулы Келли для оптимального размера ставки
    
    Формула: f* = (bp - q) / b
    где:
    - f* = оптимальная доля банкролла
    - b = коэффициент (odds - 1)
    - p = вероятность успеха
    - q = 1 - p (вероятность неудачи)
    """
    
    def __init__(self, state_file: str = "kelly_state.json"):
        self.state_file = state_file
        self.state = self._load_state()
        self.min_bet = config.MIN_KELLY_BET
        self.max_bet = config.MAX_KELLY_BET
        self.kelly_fraction = config.KELLY_FRACTION
        
    def _load_state(self) -> KellyState:
        """Загружает состояние из файла"""
        try:
            with open(self.state_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return KellyState(**data)
        except (FileNotFoundError, json.JSONDecodeError):
            logger.info("Создание нового Kelly состояния")
            return KellyState(
                current_balance=config.INITIAL_BANKROLL,
                initial_balance=config.INITIAL_BANKROLL,
                max_balance=config.INITIAL_BANKROLL,
                kelly_fraction=config.KELLY_FRACTION
            )
    
    def _save_state(self):
        """Сохраняет состояние в файл"""
        try:
            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(asdict(self.state), f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Ошибка сохранения Kelly состояния: {e}")
    
    def calculate_kelly_bet(self, probability: float, odds: float, 
                           bankroll: Optional[float] = None) -> Tuple[float, Dict]:
        """
        Рассчитывает оптимальный размер ставки по Келли
        
        Args:
            probability: Вероятность успеха (0-100)
            odds: Коэффициент
            bankroll: Текущий банкролл (если None, используется state)
        
        Returns:
            (bet_amount, details)
        """
        if bankroll is None:
            bankroll = self.state.current_balance
        
        # Конвертируем вероятность в долю
        p = probability / 100
        q = 1 - p
        b = odds - 1  # Чистый выигрыш
        
        # Расчет по формуле Келли
        if b <= 0:
            kelly_fraction = 0
        else:
            kelly_fraction = (b * p - q) / b
        
        # Применяем fractional Kelly для консервативности
        adjusted_fraction = kelly_fraction * self.kelly_fraction
        
        # Расчет суммы ставки
        bet_amount = bankroll * adjusted_fraction
        
        # Применяем ограничения
        bet_amount = max(self.min_bet, min(bet_amount, self.max_bet))
        bet_amount = min(bet_amount, bankroll * (config.MAX_BET_PERCENT / 100))
        
        # Детали для анализа
        details = {
            'kelly_fraction': kelly_fraction,
            'adjusted_fraction': adjusted_fraction,
            'probability': probability,
            'odds': odds,
            'expected_value': (p * odds - 1) * 100,  # Ожидаемая доходность в %
            'is_positive_ev': (p * odds) > 1,
            'bankroll_used': adjusted_fraction * 100  # % банкролла
        }
        
        return round(bet_amount, 2), details
    
    def get_bet_for_match(self, confidence: float, odds: float, 
                          dogon_step: int = 0) -> Tuple[float, Dict]:
        """
        Получает рекомендованную ставку для матча
        
        Args:
            confidence: Уверенность в процентах (0-100)
            odds: Коэффициент
            dogon_step: Текущий шаг догона (0, 1, 2)
        
        Returns:
            (bet_amount, details)
        """
        # Базовый расчет по Келли
        base_bet, kelly_details = self.calculate_kelly_bet(confidence, odds)
        
        # Применяем догон если есть
        if dogon_step > 0 and dogon_step < len(config.BET_PROGRESSION):
            dogon_multiplier = config.BET_PROGRESSION[dogon_step] / config.BET_PROGRESSION[0]
            base_bet *= dogon_multiplier
            kelly_details['dogon_applied'] = True
            kelly_details['dogon_multiplier'] = dogon_multiplier
        else:
            kelly_details['dogon_applied'] = False
        
        # Проверяем лимиты
        max_allowed = min(
            self.state.current_balance * (config.MAX_BET_PERCENT / 100),
            self.max_bet
        )
        final_bet = min(base_bet, max_allowed)
        
        # Если ставка меньше минимума, пропускаем
        if final_bet < self.min_bet:
            final_bet = 0
            kelly_details['skipped'] = True
            kelly_details['reason'] = f"Ставка {final_bet} меньше минимума {self.min_bet}"
        
        kelly_details['final_bet'] = round(final_bet, 2)
        kelly_details['max_allowed'] = round(max_allowed, 2)
        
        return round(final_bet, 2), kelly_details
    
    def can_place_bet(self, amount: float) -> Tuple[bool, str]:
        """Проверяет, можно ли сделать ставку"""
        if amount <= 0:
            return False, "Нулевая или отрицательная ставка"
        
        if amount > self.state.current_balance:
            return False, f"Недостаточно средств ({self.state.current_balance:.2f})"
        
        max_bet = self.state.current_balance * (config.MAX_BET_PERCENT / 100)
        if amount > max_bet:
            return False, f"Превышен максимум ({max_bet:.2f})"
        
        return True, "OK"
    
    def place_bet(self, amount: float) -> float:
        """Регистрирует размещение ставки"""
        can_bet, reason = self.can_place_bet(amount)
        
        if not can_bet:
            logger.warning(f"Невозможно сделать ставку: {reason}")
            return 0
        
        self.state.current_balance -= amount
        self.state.total_bets += 1
        self.state.last_bet_amount = amount
        
        logger.info(f"Ставка размещена: {amount:.2f} руб. (баланс: {self.state.current_balance:.2f})")
        self._save_state()
        
        return amount
    
    def record_win(self, amount: float, odds: float, round_num: int):
        """Регистрирует выигрыш"""
        profit = amount * (odds - 1)
        gross_win = amount * odds
        
        self.state.current_balance += gross_win
        self.state.total_profit += profit
        self.state.total_wins += 1
        self.state.consecutive_losses = 0
        
        if self.state.current_balance > self.state.max_balance:
            self.state.max_balance = self.state.current_balance
        
        logger.info(f"Выигрыш! Прибыль: +{profit:.2f} руб. (раунд {round_num})")
        self._save_state()
        
        return profit
    
    def record_loss(self, amount: float):
        """Регистрирует проигрыш"""
        self.state.total_losses += 1
        self.state.consecutive_losses += 1
        self.state.total_profit -= amount
        
        logger.info(f"Проигрыш. Убыток: -{amount:.2f} руб.")
        self._save_state()
        
        return -amount
    
    def get_stats(self) -> Dict:
        """Возвращает статистику"""
        total = self.state.total_wins + self.state.total_losses
        winrate = (self.state.total_wins / total * 100) if total > 0 else 0
        roi = (self.state.total_profit / self.state.initial_balance * 100) if self.state.initial_balance > 0 else 0
        
        return {
            'current_balance': self.state.current_balance,
            'initial_balance': self.state.initial_balance,
            'total_profit': self.state.total_profit,
            'roi_percent': roi,
            'total_bets': self.state.total_bets,
            'wins': self.state.total_wins,
            'losses': self.state.total_losses,
            'winrate': winrate,
            'consecutive_losses': self.state.consecutive_losses,
            'max_balance': self.state.max_balance,
            'drawdown': (self.state.max_balance - self.state.current_balance) / self.state.max_balance * 100 if self.state.max_balance > 0 else 0
        }
    
    def format_status(self) -> str:
        """Форматирует статус для вывода"""
        stats = self.get_stats()
        
        return f"""
💰 <b>KELLY BANKROLL</b>

Баланс: <b>{stats['current_balance']:.2f}</b> руб.
Прибыль: {stats['total_profit']:+.2f} руб. (ROI: {stats['roi_percent']:.1f}%)

Ставок: {stats['total_bets']} | ✅ {stats['wins']} | ❌ {stats['losses']}
Винрейт: {stats['winrate']:.1f}%
Просадка: {stats['drawdown']:.1f}%

Kelly Fraction: {self.kelly_fraction * 100:.0f}%
Min/Max Bet: {self.min_bet:.0f} / {self.max_bet:.0f} руб.
"""


# Глобальный экземпляр
kelly_manager = KellyCriterion()
