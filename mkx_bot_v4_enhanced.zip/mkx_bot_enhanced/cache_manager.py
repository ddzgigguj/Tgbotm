"""
Cache Manager с Redis для MKX Strategy Bot v4.0
Кэширование частых запросов для ускорения работы
"""

import json
import logging
import pickle
from typing import Optional, Dict, List, Any
from datetime import datetime, timedelta
import hashlib

import config

logger = logging.getLogger(__name__)

# Пробуем импортировать Redis
try:
    import redis.asyncio as redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    logger.warning("Redis не установлен. Кэширование будет отключено.")


class CacheManager:
    """
    Менеджер кэширования с Redis
    """
    
    def __init__(self):
        self.redis = None
        self.local_cache = {}  # Fallback если Redis недоступен
        self.enabled = False
        
        if REDIS_AVAILABLE:
            self._init_redis()
    
    def _init_redis(self):
        """Инициализирует подключение к Redis"""
        try:
            self.redis = redis.Redis(
                host=config.REDIS_HOST,
                port=config.REDIS_PORT,
                db=config.REDIS_DB,
                password=config.REDIS_PASSWORD,
                decode_responses=True,
                socket_connect_timeout=5
            )
            self.enabled = True
            logger.info(f"Redis подключен: {config.REDIS_HOST}:{config.REDIS_PORT}")
        except Exception as e:
            logger.error(f"Ошибка подключения к Redis: {e}")
            self.enabled = False
    
    def _make_key(self, prefix: str, *args) -> str:
        """Создает ключ кэша"""
        key_data = ':'.join(str(a) for a in args)
        return f"mkx:{prefix}:{key_data}"
    
    async def get(self, key: str) -> Optional[Any]:
        """Получает значение из кэша"""
        if not self.enabled or self.redis is None:
            # Fallback на локальный кэш
            if key in self.local_cache:
                value, expiry = self.local_cache[key]
                if datetime.now() < expiry:
                    return value
                else:
                    del self.local_cache[key]
            return None
        
        try:
            value = await self.redis.get(key)
            if value:
                return json.loads(value)
            return None
        except Exception as e:
            logger.error(f"Ошибка получения из кэша: {e}")
            return None
    
    async def set(self, key: str, value: Any, ttl: int = 3600):
        """Сохраняет значение в кэш"""
        if not self.enabled or self.redis is None:
            # Fallback на локальный кэш
            self.local_cache[key] = (value, datetime.now() + timedelta(seconds=ttl))
            return
        
        try:
            await self.redis.setex(key, ttl, json.dumps(value, default=str))
        except Exception as e:
            logger.error(f"Ошибка сохранения в кэш: {e}")
    
    async def delete(self, key: str):
        """Удаляет ключ из кэша"""
        if not self.enabled or self.redis is None:
            if key in self.local_cache:
                del self.local_cache[key]
            return
        
        try:
            await self.redis.delete(key)
        except Exception as e:
            logger.error(f"Ошибка удаления из кэша: {e}")
    
    async def clear_pattern(self, pattern: str):
        """Очищает кэш по паттерну"""
        if not self.enabled or self.redis is None:
            keys_to_delete = [k for k in self.local_cache.keys() if pattern in k]
            for k in keys_to_delete:
                del self.local_cache[k]
            return
        
        try:
            keys = await self.redis.keys(pattern)
            if keys:
                await self.redis.delete(*keys)
        except Exception as e:
            logger.error(f"Ошибка очистки кэша: {e}")
    
    # === Специфичные методы для MKX ===
    
    async def get_character_stats(self, character_name: str) -> Optional[Dict]:
        """Получает статистику персонажа из кэша"""
        key = self._make_key("char", character_name.lower())
        return await self.get(key)
    
    async def set_character_stats(self, character_name: str, stats: Dict, ttl: int = 7200):
        """Кэширует статистику персонажа"""
        key = self._make_key("char", character_name.lower())
        await self.set(key, stats, ttl)
    
    async def get_match_result(self, match_id: str) -> Optional[Dict]:
        """Получает результат матча из кэша"""
        key = self._make_key("match", match_id)
        return await self.get(key)
    
    async def set_match_result(self, match_id: str, result: Dict, ttl: int = 86400):
        """Кэширует результат матча"""
        key = self._make_key("match", match_id)
        await self.set(key, result, ttl)
    
    async def get_time_stats(self, hour: int, minute: int) -> Optional[Dict]:
        """Получает статистику по времени"""
        key = self._make_key("time", f"{hour:02d}:{minute:02d}")
        return await self.get(key)
    
    async def set_time_stats(self, hour: int, minute: int, stats: Dict, ttl: int = 3600):
        """Кэширует статистику по времени"""
        key = self._make_key("time", f"{hour:02d}:{minute:02d}")
        await self.set(key, stats, ttl)
    
    async def get_combo_stats(self, p1: str, p2: str) -> Optional[Dict]:
        """Получает статистику комбинации"""
        key = self._make_key("combo", f"{p1.lower()}_vs_{p2.lower()}")
        return await self.get(key)
    
    async def set_combo_stats(self, p1: str, p2: str, stats: Dict, ttl: int = 7200):
        """Кэширует статистику комбинации"""
        key = self._make_key("combo", f"{p1.lower()}_vs_{p2.lower()}")
        await self.set(key, stats, ttl)
    
    async def get_ml_prediction(self, features_hash: str) -> Optional[Dict]:
        """Получает кэшированное ML предсказание"""
        key = self._make_key("ml", features_hash)
        return await self.get(key)
    
    async def set_ml_prediction(self, features_hash: str, prediction: Dict, ttl: int = 300):
        """Кэширует ML предсказание (короткий TTL)"""
        key = self._make_key("ml", features_hash)
        await self.set(key, prediction, ttl)
    
    async def get_bankroll_stats(self) -> Optional[Dict]:
        """Получает статистику банкролла"""
        key = self._make_key("bankroll", "stats")
        return await self.get(key)
    
    async def set_bankroll_stats(self, stats: Dict, ttl: int = 60):
        """Кэширует статистику банкролла (очень короткий TTL)"""
        key = self._make_key("bankroll", "stats")
        await self.set(key, stats, ttl)
    
    def hash_features(self, features: Dict) -> str:
        """Создает хеш признаков для кэширования ML"""
        features_str = json.dumps(features, sort_keys=True)
        return hashlib.md5(features_str.encode()).hexdigest()[:16]
    
    async def get_stats(self) -> Dict:
        """Возвращает статистику кэша"""
        if not self.enabled or self.redis is None:
            return {
                'enabled': False,
                'local_keys': len(self.local_cache),
                'redis_keys': 0
            }
        
        try:
            info = await self.redis.info('keyspace')
            keys_count = 0
            for db_info in info.values():
                if isinstance(db_info, dict) and 'keys' in db_info:
                    keys_count = db_info['keys']
                    break
            
            return {
                'enabled': True,
                'host': config.REDIS_HOST,
                'port': config.REDIS_PORT,
                'keys': keys_count,
                'local_keys': len(self.local_cache)
            }
        except Exception as e:
            logger.error(f"Ошибка получения статистики кэша: {e}")
            return {'enabled': True, 'error': str(e)}
    
    async def clear_all(self):
        """Очищает весь кэш"""
        if not self.enabled or self.redis is None:
            self.local_cache.clear()
            logger.info("Локальный кэш очищен")
            return
        
        try:
            keys = await self.redis.keys("mkx:*")
            if keys:
                await self.redis.delete(*keys)
            logger.info(f"Redis кэш очищен ({len(keys)} ключей)")
        except Exception as e:
            logger.error(f"Ошибка очистки кэша: {e}")


class CachedDatabase:
    """
    Обертка для БД с кэшированием
    """
    
    def __init__(self, db, cache: CacheManager):
        self.db = db
        self.cache = cache
    
    async def get_character_stats(self, character_name: str) -> Dict:
        """Получает статистику персонажа (с кэшем)"""
        # Пробуем кэш
        cached = await self.cache.get_character_stats(character_name)
        if cached:
            return cached
        
        # Берем из БД
        stats = await self.db.get_character_stats_async(character_name)
        
        # Кэшируем
        if stats:
            await self.cache.set_character_stats(character_name, stats)
        
        return stats or {}
    
    async def get_time_pattern_stats(self, hour: int, minute: int) -> Dict:
        """Получает статистику по времени (с кэшем)"""
        cached = await self.cache.get_time_stats(hour, minute)
        if cached:
            return cached
        
        stats = await self.db.get_time_pattern_stats_async(hour, minute)
        
        if stats:
            await self.cache.set_time_stats(hour, minute, stats)
        
        return stats or {'total_matches': 0, 'fatality_rate': 0, 'brutality_rate': 0, 'any_finish_rate': 0}
    
    async def get_combo_stats(self, p1: str, p2: str) -> Dict:
        """Получает статистику комбинации (с кэшем)"""
        cached = await self.cache.get_combo_stats(p1, p2)
        if cached:
            return cached
        
        stats = await self.db.get_combo_stats_async(p1, p2)
        
        if stats:
            await self.cache.set_combo_stats(p1, p2, stats)
        
        return stats or {'total_matches': 0, 'fatality_rate': 0, 'avg_fatality_round': 0}


# Глобальный экземпляр
cache = CacheManager()
