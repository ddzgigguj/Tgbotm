"""
PDF Reporter для MKX Strategy Bot v4.0
Генерация PDF отчетов с графиками и статистикой
"""

import os
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from dataclasses import dataclass

import config

logger = logging.getLogger(__name__)

# Импортируем библиотеки для PDF
try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch, cm
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image, PageBreak
    from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
    from reportlab.pdfgen import canvas
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False
    logger.warning("ReportLab не установлен. PDF отчеты недоступны.")

# Импортируем matplotlib для графиков
try:
    import matplotlib
    matplotlib.use('Agg')  # Для работы без GUI
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    import seaborn as sns
    import numpy as np
    CHARTS_AVAILABLE = True
except ImportError:
    CHARTS_AVAILABLE = False
    logger.warning("Matplotlib/Seaborn не установлены. Графики недоступны.")


@dataclass
class ReportData:
    """Данные для отчета"""
    period: str
    start_date: datetime
    end_date: datetime
    total_bets: int
    wins: int
    losses: int
    profit: float
    roi: float
    winrate: float
    daily_data: List[Dict]
    hourly_data: List[Dict]
    character_stats: List[Dict]
    ml_accuracy: float


class PDFReporter:
    """
    Генератор PDF отчетов
    """
    
    def __init__(self, output_dir: str = config.REPORTS_DIR):
        self.output_dir = output_dir
        self.styles = getSampleStyleSheet() if PDF_AVAILABLE else None
        
        # Создаем директорию для отчетов
        os.makedirs(output_dir, exist_ok=True)
        
        # Кастомные стили
        if PDF_AVAILABLE:
            self.title_style = ParagraphStyle(
                'CustomTitle',
                parent=self.styles['Heading1'],
                fontSize=24,
                textColor=colors.HexColor('#1a1a2e'),
                spaceAfter=30,
                alignment=TA_CENTER
            )
            
            self.header_style = ParagraphStyle(
                'CustomHeader',
                parent=self.styles['Heading2'],
                fontSize=16,
                textColor=colors.HexColor('#16213e'),
                spaceAfter=12
            )
    
    def generate_daily_report(self, data: ReportData, filename: Optional[str] = None) -> str:
        """Генерирует дневной отчет"""
        if not PDF_AVAILABLE:
            logger.error("PDF генерация недоступна")
            return ""
        
        if filename is None:
            filename = f"daily_report_{datetime.now().strftime('%Y%m%d')}.pdf"
        
        filepath = os.path.join(self.output_dir, filename)
        
        try:
            doc = SimpleDocTemplate(
                filepath,
                pagesize=A4,
                rightMargin=72,
                leftMargin=72,
                topMargin=72,
                bottomMargin=18
            )
            
            elements = []
            
            # Заголовок
            elements.append(Paragraph("MKX Strategy Bot", self.title_style))
            elements.append(Paragraph(f"Ежедневный отчет: {data.start_date.strftime('%d.%m.%Y')}", self.styles['Heading2']))
            elements.append(Spacer(1, 0.3*inch))
            
            # Основная статистика
            elements.append(Paragraph("📊 Основная статистика", self.header_style))
            stats_data = [
                ['Метрика', 'Значение'],
                ['Всего ставок', str(data.total_bets)],
                ['Выигрыши', str(data.wins)],
                ['Проигрыши', str(data.losses)],
                ['Винрейт', f"{data.winrate:.1f}%"],
                ['Прибыль', f"{data.profit:+.2f} руб."],
                ['ROI', f"{data.roi:.1f}%"],
                ['Точность ML', f"{data.ml_accuracy:.1f}%"]
            ]
            
            stats_table = Table(stats_data, colWidths=[3*inch, 2*inch])
            stats_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#16213e')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            elements.append(stats_table)
            elements.append(Spacer(1, 0.3*inch))
            
            # Графики
            if CHARTS_AVAILABLE and data.daily_data:
                elements.append(Paragraph("📈 Графики", self.header_style))
                
                # График прибыли
                profit_chart = self._create_profit_chart(data.daily_data)
                if profit_chart:
                    elements.append(Image(profit_chart, width=6*inch, height=3*inch))
                    elements.append(Spacer(1, 0.2*inch))
                
                # График винрейта по часам
                winrate_chart = self._create_hourly_winrate_chart(data.hourly_data)
                if winrate_chart:
                    elements.append(Image(winrate_chart, width=6*inch, height=3*inch))
                    elements.append(Spacer(1, 0.2*inch))
            
            # Статистика по персонажам
            if data.character_stats:
                elements.append(PageBreak())
                elements.append(Paragraph("🎮 Статистика по персонажам", self.header_style))
                
                char_data = [['Персонаж', 'Матчей', 'Винрейт', 'Fatality%']]
                for char in sorted(data.character_stats, key=lambda x: x.get('total_matches', 0), reverse=True)[:10]:
                    char_data.append([
                        char.get('name', 'Unknown'),
                        str(char.get('total_matches', 0)),
                        f"{char.get('winrate', 0):.1f}%",
                        f"{char.get('fatality_rate', 0):.1f}%"
                    ])
                
                char_table = Table(char_data, colWidths=[2*inch, 1*inch, 1*inch, 1*inch])
                char_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0f3460')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                elements.append(char_table)
            
            # Футер
            elements.append(Spacer(1, 0.5*inch))
            elements.append(Paragraph(
                f"Отчет сгенерирован: {datetime.now().strftime('%d.%m.%Y %H:%M')} | MKX Strategy Bot v4.0",
                self.styles['Normal']
            ))
            
            # Собираем PDF
            doc.build(elements)
            logger.info(f"PDF отчет сохранен: {filepath}")
            
            return filepath
            
        except Exception as e:
            logger.error(f"Ошибка генерации PDF: {e}")
            return ""
    
    def generate_weekly_report(self, data: ReportData) -> str:
        """Генерирует недельный отчет"""
        filename = f"weekly_report_{data.start_date.strftime('%Y%m%d')}_{data.end_date.strftime('%Y%m%d')}.pdf"
        return self.generate_daily_report(data, filename)
    
    def _create_profit_chart(self, daily_data: List[Dict]) -> Optional[str]:
        """Создает график прибыли"""
        if not CHARTS_AVAILABLE:
            return None
        
        try:
            dates = [d['date'] for d in daily_data]
            profits = [d.get('profit', 0) for d in daily_data]
            cumulative = np.cumsum(profits)
            
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 6))
            
            # Дневная прибыль
            colors = ['green' if p > 0 else 'red' for p in profits]
            ax1.bar(range(len(dates)), profits, color=colors, alpha=0.7)
            ax1.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
            ax1.set_ylabel('Прибыль (руб.)')
            ax1.set_title('Дневная прибыль')
            ax1.grid(True, alpha=0.3)
            
            # Кумулятивная прибыль
            ax2.plot(range(len(dates)), cumulative, color='blue', linewidth=2, marker='o')
            ax2.fill_between(range(len(dates)), cumulative, alpha=0.3)
            ax2.set_ylabel('Кумулятивная прибыль (руб.)')
            ax2.set_xlabel('Дни')
            ax2.set_title('Общая прибыль')
            ax2.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
            chart_path = os.path.join(self.output_dir, 'profit_chart.png')
            plt.savefig(chart_path, dpi=150, bbox_inches='tight')
            plt.close()
            
            return chart_path
            
        except Exception as e:
            logger.error(f"Ошибка создания графика прибыли: {e}")
            return None
    
    def _create_hourly_winrate_chart(self, hourly_data: List[Dict]) -> Optional[str]:
        """Создает график винрейта по часам"""
        if not CHARTS_AVAILABLE:
            return None
        
        try:
            hours = [h['hour'] for h in hourly_data]
            winrates = [h.get('winrate', 0) for h in hourly_data]
            
            fig, ax = plt.subplots(figsize=(10, 4))
            
            bars = ax.bar(hours, winrates, color='steelblue', alpha=0.7)
            ax.axhline(y=50, color='red', linestyle='--', linewidth=1, label='50% baseline')
            ax.set_xlabel('Час')
            ax.set_ylabel('Винрейт (%)')
            ax.set_title('Винрейт по часам')
            ax.set_xticks(range(0, 24, 2))
            ax.legend()
            ax.grid(True, alpha=0.3, axis='y')
            
            # Подписи значений
            for bar, wr in zip(bars, winrates):
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height,
                       f'{wr:.0f}%', ha='center', va='bottom', fontsize=8)
            
            plt.tight_layout()
            
            chart_path = os.path.join(self.output_dir, 'hourly_winrate_chart.png')
            plt.savefig(chart_path, dpi=150, bbox_inches='tight')
            plt.close()
            
            return chart_path
            
        except Exception as e:
            logger.error(f"Ошибка создания графика винрейта: {e}")
            return None
    
    def _create_heatmap(self, data: List[List[float]], title: str = "Heatmap") -> Optional[str]:
        """Создает тепловую карту"""
        if not CHARTS_AVAILABLE:
            return None
        
        try:
            fig, ax = plt.subplots(figsize=(10, 6))
            
            sns.heatmap(data, cmap='RdYlGn', center=50, annot=True, fmt='.0f',
                       cbar_kws={'label': 'Винрейт %'}, ax=ax)
            ax.set_title(title)
            
            plt.tight_layout()
            
            chart_path = os.path.join(self.output_dir, 'heatmap.png')
            plt.savefig(chart_path, dpi=150, bbox_inches='tight')
            plt.close()
            
            return chart_path
            
        except Exception as e:
            logger.error(f"Ошибка создания тепловой карты: {e}")
            return None
    
    def cleanup_charts(self):
        """Удаляет временные графики"""
        try:
            for filename in ['profit_chart.png', 'hourly_winrate_chart.png', 'heatmap.png']:
                filepath = os.path.join(self.output_dir, filename)
                if os.path.exists(filepath):
                    os.remove(filepath)
        except Exception as e:
            logger.error(f"Ошибка очистки графиков: {e}")


class ReportScheduler:
    """
    Планировщик отчетов
    """
    
    def __init__(self, reporter: PDFReporter, db):
        self.reporter = reporter
        self.db = db
    
    async def generate_daily(self) -> str:
        """Генерирует ежедневный отчет"""
        try:
            # Получаем данные за сегодня
            today = datetime.now()
            start_of_day = today.replace(hour=0, minute=0, second=0, microsecond=0)
            
            # Статистика ставок
            bet_stats = await self.db.get_bet_stats_async(days=1)
            
            # Данные по часам
            hourly_data = await self.db.get_hourly_stats_async(days=1)
            
            # Статистика по персонажам
            char_stats = await self.db.get_top_characters_async(limit=10)
            
            # ML точность
            ml_accuracy = await self.db.get_ml_accuracy_async(days=1)
            
            report_data = ReportData(
                period="daily",
                start_date=start_of_day,
                end_date=today,
                total_bets=bet_stats.get('total', 0),
                wins=bet_stats.get('wins', 0),
                losses=bet_stats.get('losses', 0),
                profit=bet_stats.get('net_profit', 0),
                roi=bet_stats.get('roi', 0),
                winrate=bet_stats.get('winrate', 0),
                daily_data=[{'date': today, 'profit': bet_stats.get('net_profit', 0)}],
                hourly_data=hourly_data,
                character_stats=char_stats,
                ml_accuracy=ml_accuracy
            )
            
            filepath = self.reporter.generate_daily_report(report_data)
            self.reporter.cleanup_charts()
            
            return filepath
            
        except Exception as e:
            logger.error(f"Ошибка генерации ежедневного отчета: {e}")
            return ""


# Глобальный экземпляр
pdf_reporter = PDFReporter()
